@@ .. @@
CREATE TABLE IF NOT EXISTS topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  language_id uuid REFERENCES languages(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text DEFAULT '',
  tags text[] DEFAULT '{}',
  parent_id uuid REFERENCES topics(id) ON DELETE CASCADE,
+  is_folder boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);