/*
  # إنشاء جداول نظام التوثيق

  1. الجداول الجديدة
    - `languages`
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `icon` (text)
      - `color` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `topics`
      - `id` (uuid, primary key)
      - `language_id` (uuid, foreign key)
      - `title` (text)
      - `content` (text)
      - `tags` (text array)
      - `parent_id` (uuid, foreign key, nullable)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. الأمان
    - تفعيل RLS على جميع الجداول
    - إضافة سياسات للمستخدمين المصرح لهم
*/

-- إنشاء جدول اللغات
CREATE TABLE IF NOT EXISTS languages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  icon text DEFAULT '📝',
  color text DEFAULT '#3B82F6',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء جدول المواضيع
CREATE TABLE IF NOT EXISTS topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  language_id uuid REFERENCES languages(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text DEFAULT '',
  tags text[] DEFAULT '{}',
  parent_id uuid REFERENCES topics(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- تفعيل Row Level Security
ALTER TABLE languages ENABLE ROW LEVEL SECURITY;
ALTER TABLE topics ENABLE ROW LEVEL SECURITY;

-- إنشاء سياسات الأمان للغات
CREATE POLICY "المستخدمون يمكنهم قراءة جميع اللغات"
  ON languages
  FOR SELECT
  TO authenticated, anon
  USING (true);

CREATE POLICY "المستخدمون يمكنهم إدراج اللغات"
  ON languages
  FOR INSERT
  TO authenticated, anon
  WITH CHECK (true);

CREATE POLICY "المستخدمون يمكنهم تحديث اللغات"
  ON languages
  FOR UPDATE
  TO authenticated, anon
  USING (true);

CREATE POLICY "المستخدمون يمكنهم حذف اللغات"
  ON languages
  FOR DELETE
  TO authenticated, anon
  USING (true);

-- إنشاء سياسات الأمان للمواضيع
CREATE POLICY "المستخدمون يمكنهم قراءة جميع المواضيع"
  ON topics
  FOR SELECT
  TO authenticated, anon
  USING (true);

CREATE POLICY "المستخدمون يمكنهم إدراج المواضيع"
  ON topics
  FOR INSERT
  TO authenticated, anon
  WITH CHECK (true);

CREATE POLICY "المستخدمون يمكنهم تحديث المواضيع"
  ON topics
  FOR UPDATE
  TO authenticated, anon
  USING (true);

CREATE POLICY "المستخدمون يمكنهم حذف المواضيع"
  ON topics
  FOR DELETE
  TO authenticated, anon
  USING (true);

-- إنشاء فهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_topics_language_id ON topics(language_id);
CREATE INDEX IF NOT EXISTS idx_topics_parent_id ON topics(parent_id);
CREATE INDEX IF NOT EXISTS idx_topics_created_at ON topics(created_at);
CREATE INDEX IF NOT EXISTS idx_languages_created_at ON languages(created_at);

-- إنشاء دالة لتحديث updated_at تلقائياً
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- إنشاء المشغلات لتحديث updated_at
CREATE TRIGGER update_languages_updated_at 
    BEFORE UPDATE ON languages 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_topics_updated_at 
    BEFORE UPDATE ON topics 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();