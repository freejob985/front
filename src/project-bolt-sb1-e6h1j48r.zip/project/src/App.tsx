import React, { useEffect } from 'react';
import { ToastContainer } from 'react-toastify';
import { SplashScreen } from './components/SplashScreen';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { TopicEditor } from './components/TopicEditor';
import { useDocumentation } from './hooks/useDocumentation';
import { storage } from './utils/storage';
import 'react-toastify/dist/ReactToastify.css';
import 'highlight.js/styles/github-dark.css';

function App() {
  const [showSplash, setShowSplash] = React.useState(true);
  const [isAppReady, setIsAppReady] = React.useState(false);

  const {
    state,
    selectedLanguage,
    selectedTopic,
    filteredTopics,
    addLanguage,
    updateLanguage,
    deleteLanguage,
    addTopic,
    updateTopic,
    deleteTopic,
    selectLanguage,
    selectTopic,
    setSearchTerm,
    toggleTheme,
    toggleSidebar
  } = useDocumentation();

  const handleDataImported = () => {
    // Force a page reload to refresh all data
    window.location.reload();
  };

  // Handle splash screen completion
  const handleSplashComplete = () => {
    setShowSplash(false);
    setIsAppReady(true);
  };

  // Auto-save functionality
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      // Check if there are unsaved changes
      const hasUnsavedChanges = document.querySelector('[data-has-unsaved-changes="true"]');
      if (hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = '';
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, []);

  // Show splash screen on first load
  if (showSplash) {
    return <SplashScreen onComplete={handleSplashComplete} />;
  }

  return (
    <div className={`h-screen flex flex-col ${state.darkMode ? 'dark' : ''}`}>
      <Header
        darkMode={state.darkMode}
        sidebarCollapsed={state.sidebarCollapsed}
        onToggleTheme={toggleTheme}
        onToggleSidebar={toggleSidebar}
        onDataImported={handleDataImported}
      />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          collapsed={state.sidebarCollapsed}
          languages={state.languages}
          selectedLanguage={selectedLanguage}
          filteredTopics={filteredTopics}
          selectedTopicId={state.selectedTopicId}
          searchTerm={state.searchTerm}
          onSelectLanguage={selectLanguage}
          onAddLanguage={addLanguage}
          onUpdateLanguage={updateLanguage}
          onDeleteLanguage={deleteLanguage}
          onSelectTopic={selectTopic}
          onAddTopic={addTopic}
          onUpdateTopic={updateTopic}
          onDeleteTopic={deleteTopic}
          onSearchChange={setSearchTerm}
        />
        
        <TopicEditor
          topic={selectedTopic}
          onSave={updateTopic}
        />
      </div>

      <ToastContainer
        position="bottom-right"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme={state.darkMode ? 'dark' : 'light'}
        className="toast-container"
      />
    </div>
  );
}

export default App;