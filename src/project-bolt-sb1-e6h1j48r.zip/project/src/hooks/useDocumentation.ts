import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Language, Topic, AppState } from '../types';
import { storage } from '../utils/storage';
import { toast } from 'react-toastify';

export const useDocumentation = () => {
  const [state, setState] = useState<AppState>({
    languages: [],
    topics: [],
    selectedLanguageId: null,
    selectedTopicId: null,
    searchTerm: '',
    darkMode: false,
    sidebarCollapsed: false
  });

  // Initialize data from localStorage
  useEffect(() => {
    const initializeData = async () => {
      // Try to load from database first, then fallback to localStorage
      try {
        const { DatabaseService } = await import('../utils/database');
        const { languages: dbLanguages, topics: dbTopics } = await DatabaseService.loadFromDatabase();
        
        if (dbLanguages.length > 0 || dbTopics.length > 0) {
          // Use database data
          setState(prev => ({
            ...prev,
            languages: dbLanguages,
            topics: dbTopics,
            darkMode: storage.getTheme()
          }));
          
          // Also save to localStorage for offline access
          storage.saveLanguages(dbLanguages);
          storage.saveTopics(dbTopics);
        } else {
          // Fallback to localStorage
          const languages = storage.getLanguages();
          const topics = storage.getTopics();
          const darkMode = storage.getTheme();
          
          setState(prev => ({
            ...prev,
            languages,
            topics,
            darkMode
          }));
        }
      } catch (error) {
        console.error('Failed to load from database, using localStorage:', error);
        // Fallback to localStorage
        const languages = storage.getLanguages();
        const topics = storage.getTopics();
        const darkMode = storage.getTheme();
        
        setState(prev => ({
          ...prev,
          languages,
          topics,
          darkMode
        }));
      }
    };

    initializeData();

    // Apply theme
    const darkMode = storage.getTheme();
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  // Save languages to localStorage whenever they change
  useEffect(() => {
    if (state.languages.length > 0) {
      storage.saveLanguages(state.languages);
      // Also try to sync to database
      import('../utils/database').then(({ DatabaseService }) => {
        state.languages.forEach(lang => {
          DatabaseService.saveLanguage(lang);
        });
      }).catch(console.error);
    }
  }, [state.languages]);

  // Save topics to localStorage whenever they change
  useEffect(() => {
    if (state.topics.length > 0) {
      storage.saveTopics(state.topics);
      // Also try to sync to database
      import('../utils/database').then(({ DatabaseService }) => {
        state.topics.forEach(topic => {
          DatabaseService.saveTopic(topic);
        });
      }).catch(console.error);
    }
  }, [state.topics]);

  // Language operations
  const addLanguage = useCallback((name: string, icon: string = '📝', color: string = '#3B82F6') => {
    const newLanguage: Language = {
      id: uuidv4(),
      name,
      icon,
      color,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    setState(prev => ({
      ...prev,
      languages: [...prev.languages, newLanguage]
    }));

    toast.success(`Language "${name}" added successfully!`);
    return newLanguage;
  }, []);

  const updateLanguage = useCallback((id: string, updates: Partial<Language>) => {
    setState(prev => ({
      ...prev,
      languages: prev.languages.map(lang => 
        lang.id === id 
          ? { ...lang, ...updates, updatedAt: new Date() }
          : lang
      )
    }));
    toast.success('Language updated successfully!');
  }, []);

  const deleteLanguage = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      languages: prev.languages.filter(lang => lang.id !== id),
      topics: prev.topics.filter(topic => topic.languageId !== id),
      selectedLanguageId: prev.selectedLanguageId === id ? null : prev.selectedLanguageId,
      selectedTopicId: null
    }));
    toast.success('Language and all its topics deleted successfully!');
  }, []);

  // Topic operations
  const addTopic = useCallback((languageId: string, title: string, content: string = '', tags: string[] = [], parentId?: string, isFolder: boolean = false) => {
    const newTopic: Topic = {
      id: uuidv4(),
      languageId,
      title,
      content: isFolder ? '' : content,
      tags: isFolder ? [] : tags,
      parentId,
      isFolder,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    setState(prev => ({
      ...prev,
      topics: [...prev.topics, newTopic]
    }));

    toast.success(`${isFolder ? 'Folder' : 'Topic'} "${title}" added successfully!`);
    return newTopic;
  }, []);

  const updateTopic = useCallback((id: string, updates: Partial<Topic>) => {
    setState(prev => ({
      ...prev,
      topics: prev.topics.map(topic => 
        topic.id === id 
          ? { ...topic, ...updates, updatedAt: new Date() }
          : topic
      )
    }));
    
    const topic = state.topics.find(t => t.id === id);
    toast.success(`${topic?.isFolder ? 'Folder' : 'Topic'} updated successfully!`);
  }, []);

  const deleteTopic = useCallback((id: string) => {
    // Also delete all subtopics
    const getAllSubtopics = (topicId: string): string[] => {
      const subtopics = state.topics.filter(t => t.parentId === topicId);
      const allIds = [topicId];
      subtopics.forEach(subtopic => {
        allIds.push(...getAllSubtopics(subtopic.id));
      });
      return allIds;
    };

    const idsToDelete = getAllSubtopics(id);
    const topic = state.topics.find(t => t.id === id);

    setState(prev => ({
      ...prev,
      topics: prev.topics.filter(topic => !idsToDelete.includes(topic.id)),
      selectedTopicId: idsToDelete.includes(prev.selectedTopicId || '') ? null : prev.selectedTopicId
    }));

    toast.success(`${topic?.isFolder ? 'Folder' : 'Topic'} and all items deleted successfully!`);
  }, [state.topics]);

  // Selection operations
  const selectLanguage = useCallback((id: string | null) => {
    setState(prev => ({
      ...prev,
      selectedLanguageId: id,
      selectedTopicId: null
    }));
  }, []);

  const selectTopic = useCallback((id: string | null) => {
    setState(prev => ({
      ...prev,
      selectedTopicId: id
    }));
  }, []);

  // Search and filter
  const setSearchTerm = useCallback((term: string) => {
    setState(prev => ({
      ...prev,
      searchTerm: term
    }));
  }, []);

  // Theme toggle
  const toggleTheme = useCallback(() => {
    setState(prev => {
      const newDarkMode = !prev.darkMode;
      storage.saveTheme(newDarkMode);
      
      // Apply theme immediately
      if (newDarkMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      
      return {
        ...prev,
        darkMode: newDarkMode
      };
    });
  }, []);

  // Sidebar toggle
  const toggleSidebar = useCallback(() => {
    setState(prev => ({
      ...prev,
      sidebarCollapsed: !prev.sidebarCollapsed
    }));
  }, []);

  // Computed values
  const selectedLanguage = state.languages.find(lang => lang.id === state.selectedLanguageId) || null;
  const selectedTopic = state.topics.find(topic => topic.id === state.selectedTopicId) || null;
  
  const filteredTopics = state.topics.filter(topic => {
    if (!state.selectedLanguageId || topic.languageId !== state.selectedLanguageId) return false;
    if (!state.searchTerm) return true;
    
    const searchLower = state.searchTerm.toLowerCase();
    return (
      topic.title.toLowerCase().includes(searchLower) ||
      topic.content.toLowerCase().includes(searchLower) ||
      topic.tags.some(tag => tag.toLowerCase().includes(searchLower))
    );
  });

  return {
    state,
    selectedLanguage,
    selectedTopic,
    filteredTopics,
    addLanguage,
    updateLanguage,
    deleteLanguage,
    addTopic,
    updateTopic,
    deleteTopic,
    selectLanguage,
    selectTopic,
    setSearchTerm,
    toggleTheme,
    toggleSidebar
  };
};