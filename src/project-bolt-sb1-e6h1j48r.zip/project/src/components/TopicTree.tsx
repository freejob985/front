import React, { useState, useCallback } from 'react';
import { ChevronRight, ChevronDown, File, Folder, FolderPlus, Plus, Edit2, Trash2 } from 'lucide-react';
import Swal from 'sweetalert2';
import { Topic } from '../types';

interface TopicTreeProps {
  topics: Topic[];
  selectedTopicId: string | null;
  onSelectTopic: (id: string | null) => void;
  onAddTopic: (title: string, parentId?: string, isFolder?: boolean) => void;
  onUpdateTopic: (id: string, updates: Partial<Topic>) => void;
  onDeleteTopic: (id: string) => void;
}

interface TreeItemProps {
  topic: Topic;
  subtopics: Topic[];
  level: number;
  isSelected: boolean;
  onSelect: () => void;
  onAddSubtopic: () => void;
  onAddSubfolder: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

const TreeItem: React.FC<TreeItemProps & { children?: React.ReactNode }> = ({
  topic,
  subtopics,
  level,
  isSelected,
  onSelect,
  onAddSubtopic,
  onAddSubfolder,
  onEdit,
  onDelete,
  children
}) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const hasSubtopics = subtopics.length > 0;

  return (
    <div className="w-full">
      <div
        className={`group flex items-center gap-2 px-2 py-2 rounded-lg cursor-pointer transition-colors ${
          isSelected 
            ? 'bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300' 
            : 'hover:bg-gray-100 dark:hover:bg-gray-700'
        }`}
        style={{ paddingLeft: `${(level * 16) + 8}px` }}
        onClick={topic.isFolder ? undefined : onSelect}
      >
        {hasSubtopics || topic.isFolder ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsExpanded(!isExpanded);
            }}
            className="p-1 rounded hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
          >
            {isExpanded ? (
              <ChevronDown className="w-3 h-3" />
            ) : (
              <ChevronRight className="w-3 h-3" />
            )}
          </button>
        ) : (
          <div className="w-5 h-5 flex items-center justify-center">
            <File className="w-3 h-3 text-gray-400" />
          </div>
        )}

        {topic.isFolder && (
          <Folder className="w-4 h-4 text-yellow-500" />
        )}

        <span className={`flex-1 text-sm font-medium truncate text-gray-900 dark:text-white ${
          topic.isFolder ? 'font-semibold' : ''
        }`}>
          {topic.title}
        </span>

        <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1 transition-opacity">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onAddSubfolder();
            }}
            className="p-1 rounded hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
            title="Add subfolder"
          >
            <FolderPlus className="w-3 h-3 text-yellow-600" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onAddSubtopic();
            }}
            className="p-1 rounded hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
            title="Add subtopic"
          >
            <Plus className="w-3 h-3 text-gray-500" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onEdit();
            }}
            className="p-1 rounded hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
            title="Edit topic"
          >
            <Edit2 className="w-3 h-3 text-gray-500" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDelete();
            }}
            className="p-1 rounded hover:bg-red-100 dark:hover:bg-red-900/20 transition-colors"
            title="Delete topic"
          >
            <Trash2 className="w-3 h-3 text-red-500" />
          </button>
        </div>
      </div>

      {hasSubtopics && isExpanded && (
        <div className="w-full">
          {children}
        </div>
      )}
    </div>
  );
};

const TopicTreeItem: React.FC<{
  topic: Topic;
  allTopics: Topic[];
  level: number;
  isSelected: boolean;
  selectedTopicId: string | null;
  onSelect: () => void;
  onSelectTopic: (id: string | null) => void;
  onAddSubtopic: () => void;
  onAddSubfolder: () => void;
  onEdit: () => void;
  onDelete: () => void;
}> = ({ 
  topic, 
  allTopics, 
  level, 
  isSelected, 
  selectedTopicId,
  onSelect, 
  onSelectTopic,
  onAddSubtopic, 
  onAddSubfolder, 
  onEdit, 
  onDelete 
}) => {
  const subtopics = allTopics.filter(t => t.parentId === topic.id);
  
  return (
    <TreeItem
      topic={topic}
      subtopics={subtopics}
      level={level}
      isSelected={isSelected}
      onSelect={onSelect}
      onAddSubtopic={onAddSubtopic}
      onAddSubfolder={onAddSubfolder}
      onEdit={onEdit}
      onDelete={onDelete}
    >
      {subtopics.map((subtopic) => (
        <TopicTreeItem
          key={subtopic.id}
          topic={subtopic}
          allTopics={allTopics}
          level={level + 1}
          isSelected={selectedTopicId === subtopic.id}
          selectedTopicId={selectedTopicId}
          onSelect={() => !subtopic.isFolder && onSelectTopic(subtopic.id)}
          onSelectTopic={onSelectTopic}
          onAddSubtopic={() => handleAddTopic(subtopic.id, false)}
          onAddSubfolder={() => handleAddTopic(subtopic.id, true)}
          onEdit={() => handleEditTopic(subtopic)}
          onDelete={() => handleDeleteTopic(subtopic)}
        />
      ))}
    </TreeItem>
  );
};

export const TopicTree: React.FC<TopicTreeProps> = ({
  topics,
  selectedTopicId,
  onSelectTopic,
  onAddTopic,
  onUpdateTopic,
  onDeleteTopic
}) => {
  const rootTopics = topics.filter(topic => !topic.parentId);

  const handleAddTopic = useCallback(async (parentId?: string, isFolder: boolean = false) => {
    const { value: title } = await Swal.fire({
      title: parentId 
        ? (isFolder ? 'Add Subfolder' : 'Add Subtopic')
        : (isFolder ? 'Add Folder' : 'Add Topic'),
      input: 'textarea',
      inputPlaceholder: isFolder 
        ? 'Enter folder names (one per line):\nFolder 1\nFolder 2\nFolder 3' 
        : 'Enter topic titles (one per line):\nTopic 1\nTopic 2\nTopic 3',
      showCancelButton: true,
      confirmButtonText: 'Add',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#3B82F6',
      inputAttributes: {
        rows: '5',
        style: 'resize: vertical; min-height: 100px;'
      },
      inputValidator: (value) => {
        if (!value || !value.trim()) {
          return isFolder ? 'Folder name is required' : 'Topic title is required';
        }
        
        const lines = value.split('\n').map(line => line.trim()).filter(line => line.length > 0);
        const duplicates = lines.filter(line => 
          topics.some(t => t.title.toLowerCase() === line.toLowerCase() && t.parentId === parentId)
        );
        
        if (duplicates.length > 0) {
          return `${isFolder ? 'Folders' : 'Topics'} already exist: ${duplicates.join(', ')}`;
        }
      }
    });

    if (title) {
      const lines = title.split('\n').map(line => line.trim()).filter(line => line.length > 0);
      lines.forEach(line => {
        onAddTopic(line, parentId, isFolder);
      });
    }
  }, [topics, onAddTopic]);

  const handleAddFolder = useCallback(async (parentId?: string) => {
    await handleAddTopic(parentId, true);
  }, [handleAddTopic]);

  const handleEditTopic = useCallback(async (topic: Topic) => {
    const { value: formValues } = await Swal.fire({
      title: topic.isFolder ? 'Edit Folder' : 'Edit Topic',
      html: `
        <div class="space-y-4">
          <div>
            <label class="block text-sm font-medium mb-2">Title:</label>
            <input id="title" class="w-full p-2 border rounded" value="${topic.title}">
          </div>
          ${!topic.isFolder ? `
          <div>
            <label class="block text-sm font-medium mb-2">Tags (comma-separated):</label>
            <input id="tags" class="w-full p-2 border rounded" value="${topic.tags.join(', ')}" placeholder="e.g., basics, advanced, important">
          </div>
          ` : ''}
        </div>
      `,
      showCancelButton: true,
      confirmButtonText: 'Update',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#3B82F6',
      preConfirm: () => {
        const title = (document.getElementById('title') as HTMLInputElement).value;
        if (!title.trim()) {
          Swal.showValidationMessage('Title is required');
          return false;
        }

        const result: any = { title: title.trim() };
        
        if (!topic.isFolder) {
          const tagsInput = (document.getElementById('tags') as HTMLInputElement).value;
          const tags = tagsInput
            .split(',')
            .map(tag => tag.trim())
            .filter(tag => tag.length > 0);
          result.tags = tags;
        }

        return result;
      }
    });

    if (formValues) {
      onUpdateTopic(topic.id, formValues);
    }
  }, [onUpdateTopic]);

  const handleDeleteTopic = useCallback(async (topic: Topic) => {
    const subtopics = topics.filter(t => t.parentId === topic.id);
    const hasSubtopics = subtopics.length > 0;

    const result = await Swal.fire({
      title: topic.isFolder ? 'Delete Folder' : 'Delete Topic',
      text: hasSubtopics 
        ? `Are you sure you want to delete "${topic.title}" and all its ${subtopics.length} item(s)?`
        : `Are you sure you want to delete "${topic.title}"?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#EF4444',
      cancelButtonColor: '#6B7280',
      confirmButtonText: 'Yes, delete it',
      cancelButtonText: 'Cancel'
    });

    if (result.isConfirmed) {
      onDeleteTopic(topic.id);
    }
  }, [topics, onDeleteTopic]);

  if (rootTopics.length === 0) {
    return (
      <div className="p-4 text-center">
        <div className="text-gray-500 dark:text-gray-400 mb-4">
          <File className="w-8 h-8 mx-auto mb-2" />
          <p>No topics yet</p>
          <p className="text-sm">Add your first topic to get started!</p>
        </div>
        <div className="flex gap-2 justify-center">
          <button
            onClick={() => handleAddFolder()}
            className="inline-flex items-center gap-2 px-3 py-2 text-sm bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors"
          >
            <FolderPlus className="w-4 h-4" />
            Add Folder
          </button>
          <button
            onClick={() => handleAddTopic()}
            className="inline-flex items-center gap-2 px-3 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Topic
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-1">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wide">
          Topics
        </h3>
        <div className="flex gap-1">
          <button
            onClick={() => handleAddFolder()}
            className="p-1.5 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            title="Add new folder"
          >
            <FolderPlus className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />
          </button>
          <button
            onClick={() => handleAddTopic()}
            className="p-1.5 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            title="Add new topic"
          >
            <Plus className="w-4 h-4 text-gray-500 dark:text-gray-400" />
          </button>
        </div>
      </div>
      
      {rootTopics.map((topic) => (
        <TopicTreeItem
          key={topic.id}
          topic={topic}
          allTopics={topics}
          level={0}
          isSelected={selectedTopicId === topic.id}
          selectedTopicId={selectedTopicId}
          onSelect={() => !topic.isFolder && onSelectTopic(topic.id)}
          onSelectTopic={onSelectTopic}
          onAddSubtopic={() => handleAddTopic(topic.id, false)}
          onAddSubfolder={() => handleAddTopic(topic.id, true)}
          onEdit={() => handleEditTopic(topic)}
          onDelete={() => handleDeleteTopic(topic)}
        />
      ))}
    </div>
  );
};