import React from 'react';
import { LanguageSelector } from './LanguageSelector';
import { SearchBar } from './SearchBar';
import { TopicTree } from './TopicTree';
import { Language, Topic } from '../types';

interface SidebarProps {
  collapsed: boolean;
  languages: Language[];
  selectedLanguage: Language | null;
  filteredTopics: Topic[];
  selectedTopicId: string | null;
  searchTerm: string;
  onSelectLanguage: (id: string | null) => void;
  onAddLanguage: (name: string, icon: string, color: string) => void;
  onUpdateLanguage: (id: string, updates: Partial<Language>) => void;
  onDeleteLanguage: (id: string) => void;
  onSelectTopic: (id: string | null) => void;
  onAddTopic: (languageId: string, title: string, content?: string, tags?: string[], parentId?: string, isFolder?: boolean) => void;
  onUpdateTopic: (id: string, updates: Partial<Topic>) => void;
  onDeleteTopic: (id: string) => void;
  onSearchChange: (term: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  collapsed,
  languages,
  selectedLanguage,
  filteredTopics,
  selectedTopicId,
  searchTerm,
  onSelectLanguage,
  onAddLanguage,
  onUpdateLanguage,
  onDeleteLanguage,
  onSelectTopic,
  onAddTopic,
  onUpdateTopic,
  onDeleteTopic,
  onSearchChange
}) => {
  if (collapsed) {
    return (
      <div className="w-16 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700">
        <div className="p-4">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
            <span className="text-white text-lg">📚</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-80 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 flex flex-col">
      <LanguageSelector
        languages={languages}
        selectedLanguage={selectedLanguage}
        onSelectLanguage={onSelectLanguage}
        onAddLanguage={onAddLanguage}
        onUpdateLanguage={onUpdateLanguage}
        onDeleteLanguage={onDeleteLanguage}
      />

      {selectedLanguage && (
        <>
          <SearchBar
            searchTerm={searchTerm}
            onSearchChange={onSearchChange}
          />
          
          <div className="flex-1 overflow-auto">
            <TopicTree
              topics={filteredTopics}
              selectedTopicId={selectedTopicId}
              onSelectTopic={onSelectTopic}
              onAddTopic={(title, parentId, isFolder) => onAddTopic(selectedLanguage.id, title, '', [], parentId, isFolder)}
              onUpdateTopic={onUpdateTopic}
              onDeleteTopic={onDeleteTopic}
            />
          </div>
        </>
      )}

      {!selectedLanguage && (
        <div className="flex-1 flex items-center justify-center p-8">
          <div className="text-center text-gray-500 dark:text-gray-400">
            <div className="w-12 h-12 bg-gray-200 dark:bg-gray-700 rounded-lg flex items-center justify-center mx-auto mb-4">
              🎯
            </div>
            <p className="text-sm">Select a language to view topics</p>
          </div>
        </div>
      )}
    </div>
  );
};