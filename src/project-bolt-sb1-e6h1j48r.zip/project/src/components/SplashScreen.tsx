import React, { useEffect, useState } from 'react';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    'تحميل النظام...',
    'تهيئة قاعدة البيانات...',
    'تحميل اللغات...',
    'إعداد المحرر...',
    'جاهز للاستخدام!'
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 500);
          return 100;
        }
        return prev + 2;
      });
    }, 50);

    return () => clearInterval(timer);
  }, [onComplete]);

  useEffect(() => {
    const stepTimer = setInterval(() => {
      setCurrentStep(prev => {
        if (prev >= steps.length - 1) {
          clearInterval(stepTimer);
          return prev;
        }
        return prev + 1;
      });
    }, 600);

    return () => clearInterval(stepTimer);
  }, []);

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 flex items-center justify-center z-50">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-white opacity-10 rounded-full animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-white opacity-5 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-white opacity-5 rounded-full animate-ping delay-500"></div>
      </div>

      <div className="relative z-10 text-center">
        {/* Logo Animation */}
        <div className="mb-8 relative">
          <div className="w-32 h-32 mx-auto mb-6 relative">
            {/* Main Logo SVG */}
            <svg width="128" height="128" viewBox="0 0 128 128" className="animate-bounce">
              <defs>
                <linearGradient id="logo-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" style={{stopColor:'#FFFFFF', stopOpacity:1}} />
                  <stop offset="100%" style={{stopColor:'#F1F5F9', stopOpacity:1}} />
                </linearGradient>
                <filter id="glow">
                  <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                  <feMerge> 
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
              </defs>
              
              {/* Book */}
              <rect x="24" y="32" width="80" height="64" rx="8" fill="url(#logo-gradient)" filter="url(#glow)"/>
              <rect x="24" y="32" width="10" height="64" rx="5" fill="#FFFFFF"/>
              
              {/* Pages */}
              <rect x="40" y="44" width="56" height="2" rx="1" fill="#3B82F6" opacity="0.7"/>
              <rect x="40" y="52" width="48" height="2" rx="1" fill="#3B82F6" opacity="0.7"/>
              <rect x="40" y="60" width="52" height="2" rx="1" fill="#3B82F6" opacity="0.7"/>
              <rect x="40" y="68" width="44" height="2" rx="1" fill="#3B82F6" opacity="0.7"/>
              <rect x="40" y="76" width="50" height="2" rx="1" fill="#3B82F6" opacity="0.7"/>
              
              {/* Code Symbol */}
              <g transform="translate(88, 24)">
                <circle cx="0" cy="0" r="12" fill="#10B981" className="animate-pulse"/>
                <path d="M-6 -3 L-2 0 L-6 3" stroke="white" strokeWidth="2" fill="none" strokeLinecap="round"/>
                <path d="M6 -3 L2 0 L6 3" stroke="white" strokeWidth="2" fill="none" strokeLinecap="round"/>
              </g>
            </svg>
            
            {/* Rotating Ring */}
            <div className="absolute inset-0 border-4 border-white border-opacity-30 rounded-full animate-spin" style={{animationDuration: '3s'}}></div>
          </div>
          
          {/* Title */}
          <h1 className="text-4xl font-bold text-white mb-2 animate-fadeIn">
            نظام التوثيق البرمجي
          </h1>
          <p className="text-blue-100 text-lg animate-fadeIn delay-300">
            Programming Documentation System
          </p>
        </div>

        {/* Progress Section */}
        <div className="w-80 mx-auto">
          {/* Progress Bar */}
          <div className="bg-white bg-opacity-20 rounded-full h-3 mb-4 overflow-hidden">
            <div 
              className="bg-gradient-to-r from-green-400 to-blue-400 h-full rounded-full transition-all duration-300 ease-out relative"
              style={{ width: `${progress}%` }}
            >
              <div className="absolute inset-0 bg-white bg-opacity-30 animate-pulse"></div>
            </div>
          </div>
          
          {/* Progress Text */}
          <div className="text-white text-center">
            <p className="text-lg font-medium mb-2">{steps[currentStep]}</p>
            <p className="text-blue-200 text-sm">{Math.round(progress)}%</p>
          </div>
        </div>

        {/* Loading Dots */}
        <div className="flex justify-center space-x-2 mt-8">
          <div className="w-3 h-3 bg-white rounded-full animate-bounce"></div>
          <div className="w-3 h-3 bg-white rounded-full animate-bounce delay-100"></div>
          <div className="w-3 h-3 bg-white rounded-full animate-bounce delay-200"></div>
        </div>

        {/* Features Preview */}
        <div className="mt-12 grid grid-cols-3 gap-6 text-white text-sm opacity-70">
          <div className="text-center">
            <div className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-2">
              📝
            </div>
            <p>محرر متقدم</p>
          </div>
          <div className="text-center">
            <div className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-2">
              🗄️
            </div>
            <p>قاعدة بيانات</p>
          </div>
          <div className="text-center">
            <div className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-2">
              🎨
            </div>
            <p>تصميم جميل</p>
          </div>
        </div>
      </div>
    </div>
  );
};