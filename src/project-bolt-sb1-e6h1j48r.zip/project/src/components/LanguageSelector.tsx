import React, { useState } from 'react';
import { Plus, Edit2, Trash2, ChevronDown } from 'lucide-react';
import Swal from 'sweetalert2';
import { Language } from '../types';

interface LanguageSelectorProps {
  languages: Language[];
  selectedLanguage: Language | null;
  onSelectLanguage: (id: string | null) => void;
  onAddLanguage: (name: string, icon: string, color: string) => void;
  onUpdateLanguage: (id: string, updates: Partial<Language>) => void;
  onDeleteLanguage: (id: string) => void;
}

const LANGUAGE_PRESETS = [
  { name: 'JavaScript', icon: '🟨', color: '#F7DF1E' },
  { name: 'Python', icon: '🐍', color: '#3776AB' },
  { name: 'Java', icon: '☕', color: '#ED8B00' },
  { name: 'C++', icon: '⚡', color: '#00599C' },
  { name: 'React', icon: '⚛️', color: '#61DAFB' },
  { name: 'TypeScript', icon: '📘', color: '#3178C6' },
  { name: 'Node.js', icon: '🟢', color: '#339933' },
  { name: 'HTML', icon: '🌐', color: '#E34F26' },
  { name: 'CSS', icon: '🎨', color: '#1572B6' },
  { name: 'PHP', icon: '🐘', color: '#777BB4' },
  { name: 'Go', icon: '🏃', color: '#00ADD8' },
  { name: 'Rust', icon: '🦀', color: '#000000' },
  { name: 'Swift', icon: '🍎', color: '#FA7343' },
  { name: 'Kotlin', icon: '📱', color: '#7F52FF' }
];

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({
  languages,
  selectedLanguage,
  onSelectLanguage,
  onAddLanguage,
  onUpdateLanguage,
  onDeleteLanguage
}) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const handleAddLanguage = async () => {
    const { value: formValues } = await Swal.fire({
      title: 'Add New Language',
      html: `
        <div class="space-y-4">
          <div>
            <label class="block text-sm font-medium mb-2">Choose a preset or create custom:</label>
            <select id="preset" class="w-full p-2 border rounded">
              <option value="">Custom Language</option>
              ${LANGUAGE_PRESETS.map(preset => 
                `<option value="${preset.name}">${preset.icon} ${preset.name}</option>`
              ).join('')}
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium mb-2">Language Name:</label>
            <input id="name" class="w-full p-2 border rounded" placeholder="e.g., JavaScript">
          </div>
          <div>
            <label class="block text-sm font-medium mb-2">Icon (emoji):</label>
            <input id="icon" class="w-full p-2 border rounded" placeholder="e.g., 🟨" maxlength="2">
          </div>
          <div>
            <label class="block text-sm font-medium mb-2">Color:</label>
            <input id="color" type="color" class="w-full p-1 border rounded h-10" value="#3B82F6">
          </div>
        </div>
      `,
      showCancelButton: true,
      confirmButtonText: 'Add Language',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#3B82F6',
      didOpen: () => {
        const presetSelect = document.getElementById('preset') as HTMLSelectElement;
        const nameInput = document.getElementById('name') as HTMLInputElement;
        const iconInput = document.getElementById('icon') as HTMLInputElement;
        const colorInput = document.getElementById('color') as HTMLInputElement;

        presetSelect.onchange = () => {
          const selectedPreset = LANGUAGE_PRESETS.find(p => p.name === presetSelect.value);
          if (selectedPreset) {
            nameInput.value = selectedPreset.name;
            iconInput.value = selectedPreset.icon;
            colorInput.value = selectedPreset.color;
          }
        };
      },
      preConfirm: () => {
        const name = (document.getElementById('name') as HTMLInputElement).value;
        const icon = (document.getElementById('icon') as HTMLInputElement).value || '📝';
        const color = (document.getElementById('color') as HTMLInputElement).value;

        if (!name.trim()) {
          Swal.showValidationMessage('Language name is required');
          return false;
        }

        if (languages.some(lang => lang.name.toLowerCase() === name.toLowerCase())) {
          Swal.showValidationMessage('Language already exists');
          return false;
        }

        return { name: name.trim(), icon, color };
      }
    });

    if (formValues) {
      onAddLanguage(formValues.name, formValues.icon, formValues.color);
    }
  };

  const handleEditLanguage = async (language: Language) => {
    const { value: formValues } = await Swal.fire({
      title: 'Edit Language',
      html: `
        <div class="space-y-4">
          <div>
            <label class="block text-sm font-medium mb-2">Language Name:</label>
            <input id="name" class="w-full p-2 border rounded" value="${language.name}">
          </div>
          <div>
            <label class="block text-sm font-medium mb-2">Icon (emoji):</label>
            <input id="icon" class="w-full p-2 border rounded" value="${language.icon}" maxlength="2">
          </div>
          <div>
            <label class="block text-sm font-medium mb-2">Color:</label>
            <input id="color" type="color" class="w-full p-1 border rounded h-10" value="${language.color}">
          </div>
        </div>
      `,
      showCancelButton: true,
      confirmButtonText: 'Update Language',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#3B82F6',
      preConfirm: () => {
        const name = (document.getElementById('name') as HTMLInputElement).value;
        const icon = (document.getElementById('icon') as HTMLInputElement).value;
        const color = (document.getElementById('color') as HTMLInputElement).value;

        if (!name.trim()) {
          Swal.showValidationMessage('Language name is required');
          return false;
        }

        return { name: name.trim(), icon, color };
      }
    });

    if (formValues) {
      onUpdateLanguage(language.id, formValues);
    }
  };

  const handleDeleteLanguage = async (language: Language) => {
    const result = await Swal.fire({
      title: 'Delete Language',
      text: `Are you sure you want to delete "${language.name}" and all its topics?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#EF4444',
      cancelButtonColor: '#6B7280',
      confirmButtonText: 'Yes, delete it',
      cancelButtonText: 'Cancel'
    });

    if (result.isConfirmed) {
      onDeleteLanguage(language.id);
    }
  };

  return (
    <div className="border-b border-gray-200 dark:border-gray-700 p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
          Programming Languages
        </h2>
        <button
          onClick={handleAddLanguage}
          className="inline-flex items-center gap-2 px-3 py-1.5 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Language
        </button>
      </div>

      {languages.length === 0 ? (
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          <p>No languages added yet.</p>
          <p className="text-sm mt-1">Click "Add Language" to get started!</p>
        </div>
      ) : (
        <div className="relative">
          <button
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="w-full flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <div className="flex items-center gap-3">
              {selectedLanguage ? (
                <>
                  <span 
                    className="w-6 h-6 rounded flex items-center justify-center text-sm"
                    style={{ backgroundColor: selectedLanguage.color + '20', color: selectedLanguage.color }}
                  >
                    {selectedLanguage.icon}
                  </span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {selectedLanguage.name}
                  </span>
                </>
              ) : (
                <span className="text-gray-500 dark:text-gray-400">
                  Select a language...
                </span>
              )}
            </div>
            <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${
              isDropdownOpen ? 'rotate-180' : ''
            }`} />
          </button>

          {isDropdownOpen && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-50">
              {languages.map((language) => (
                <div
                  key={language.id}
                  className="flex items-center gap-3 p-3 hover:bg-gray-50 dark:hover:bg-gray-700 border-b border-gray-100 dark:border-gray-700 last:border-b-0"
                >
                  <button
                    onClick={() => {
                      onSelectLanguage(language.id);
                      setIsDropdownOpen(false);
                    }}
                    className="flex items-center gap-3 flex-1"
                  >
                    <span 
                      className="w-6 h-6 rounded flex items-center justify-center text-sm"
                      style={{ backgroundColor: language.color + '20', color: language.color }}
                    >
                      {language.icon}
                    </span>
                    <span className="font-medium text-gray-900 dark:text-white">
                      {language.name}
                    </span>
                  </button>
                  
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleEditLanguage(language)}
                      className="p-1.5 rounded hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                      title="Edit language"
                    >
                      <Edit2 className="w-3 h-3 text-gray-500 dark:text-gray-400" />
                    </button>
                    <button
                      onClick={() => handleDeleteLanguage(language)}
                      className="p-1.5 rounded hover:bg-red-100 dark:hover:bg-red-900/20 transition-colors"
                      title="Delete language"
                    >
                      <Trash2 className="w-3 h-3 text-red-500" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};