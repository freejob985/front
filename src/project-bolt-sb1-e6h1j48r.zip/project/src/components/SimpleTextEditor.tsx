import React, { useRef, useEffect, useState } from 'react';
import { Save, Eye, Edit3, Maximize2, Minimize2, Bold, Italic, Code, List, Quote, ListOrdered, Heading1, Heading2, Heading3, Link, Image, Strikethrough, AlignLeft, AlignCenter, AlignRight, Table, SeparatorVertical as Separator, Type, Palette } from 'lucide-react';

interface SimpleTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  onSave?: () => void;
  placeholder?: string;
  className?: string;
}

export const SimpleTextEditor: React.FC<SimpleTextEditorProps> = ({
  value,
  onChange,
  onSave,
  placeholder = "Start writing your documentation here...",
  className = ""
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [isPreview, setIsPreview] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [textDirection, setTextDirection] = useState<'ltr' | 'rtl'>('ltr');

  // Handle textarea change
  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onChange(e.target.value);
  };

  // Handle keyboard shortcuts
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const textarea = e.currentTarget;
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const newValue = value.substring(0, start) + '  ' + value.substring(end);
      onChange(newValue);
      
      requestAnimationFrame(() => {
        if (textareaRef.current) {
          textareaRef.current.setSelectionRange(start + 2, start + 2);
        }
      });
    } else if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      onSave?.();
    }
  };

  // Auto-resize textarea
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea && !isPreview) {
      textarea.style.height = 'auto';
      textarea.style.height = Math.max(400, textarea.scrollHeight) + 'px';
    }
  }, [value, isPreview]);

  // Format text helper
  const formatText = (before: string, after: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = value.substring(start, end);
    
    const newValue = value.substring(0, start) + before + selectedText + after + value.substring(end);
    onChange(newValue);

    requestAnimationFrame(() => {
      if (textareaRef.current) {
        const newCursorPos = start + before.length + selectedText.length;
        textareaRef.current.setSelectionRange(newCursorPos, newCursorPos);
      }
    });
  };

  // Insert text at cursor
  const insertText = (text: string) => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const newValue = value.substring(0, start) + text + value.substring(end);
    onChange(newValue);

    requestAnimationFrame(() => {
      if (textareaRef.current) {
        const newCursorPos = start + text.length;
        textareaRef.current.setSelectionRange(newCursorPos, newCursorPos);
      }
    });
  };

  // Toggle preview mode
  const togglePreview = () => {
    setIsPreview(!isPreview);
  };

  // Convert markdown to HTML for preview
  const getPreviewHTML = () => {
    let html = value
      // Headers
      .replace(/^### (.*$)/gm, '<h3 class="text-lg font-semibold mb-2 text-gray-900 dark:text-white border-b border-gray-200 dark:border-gray-700 pb-1">$1</h3>')
      .replace(/^## (.*$)/gm, '<h2 class="text-xl font-semibold mb-3 text-gray-900 dark:text-white border-b-2 border-blue-500 pb-2">$1</h2>')
      .replace(/^# (.*$)/gm, '<h1 class="text-2xl font-bold mb-4 text-gray-900 dark:text-white border-b-2 border-blue-600 pb-2">$1</h1>')
      // Text formatting
      .replace(/\*\*(.*?)\*\*/g, '<strong class="font-bold text-gray-900 dark:text-white">$1</strong>')
      .replace(/\*(.*?)\*/g, '<em class="italic text-gray-800 dark:text-gray-200">$1</em>')
      .replace(/~~(.*?)~~/g, '<del class="line-through text-gray-600 dark:text-gray-400">$1</del>')
      // Links
      .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" class="text-blue-600 dark:text-blue-400 hover:underline" target="_blank" rel="noopener noreferrer">$1</a>')
      // Images
      .replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1" class="max-w-full h-auto rounded-lg shadow-md my-4" />')
      // Code blocks
      .replace(/```([\s\S]*?)```/g, '<pre class="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg mb-4 overflow-x-auto border border-gray-200 dark:border-gray-700"><code class="text-sm font-mono text-gray-800 dark:text-gray-200">$1</code></pre>')
      // Inline code
      .replace(/`(.*?)`/g, '<code class="bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded text-sm font-mono text-red-600 dark:text-red-400 border">$1</code>')
      // Tables
      .replace(/\|(.+)\|/g, (match, content) => {
        const cells = content.split('|').map((cell: string) => cell.trim());
        return '<tr>' + cells.map((cell: string) => `<td class="border border-gray-300 dark:border-gray-600 px-3 py-2">${cell}</td>`).join('') + '</tr>';
      })
      // Quotes
      .replace(/^> (.*$)/gm, '<blockquote class="border-l-4 border-blue-500 pl-4 italic text-gray-600 dark:text-gray-400 mb-4 bg-blue-50 dark:bg-blue-900/20 py-2 rounded-r">$1</blockquote>')
      // Horizontal rule
      .replace(/^---$/gm, '<hr class="border-t-2 border-gray-300 dark:border-gray-600 my-6" />')
      // Lists
      .replace(/^- (.*$)/gm, '<li class="mb-1 text-gray-700 dark:text-gray-300">$1</li>')
      .replace(/^\d+\. (.*$)/gm, '<li class="mb-1 text-gray-700 dark:text-gray-300">$1</li>')
      // Line breaks
      .replace(/\n\n/g, '</p><p class="mb-3 text-gray-700 dark:text-gray-300">')
      .replace(/\n/g, '<br>');

    // Wrap in paragraph tags if needed
    if (html && !html.startsWith('<h') && !html.startsWith('<ul') && !html.startsWith('<ol') && !html.startsWith('<blockquote') && !html.startsWith('<pre')) {
      html = '<p class="mb-3 text-gray-700 dark:text-gray-300">' + html + '</p>';
    }

    // Wrap consecutive <li> elements in <ul> or <ol>
    html = html.replace(/(<li>.*?<\/li>(?:<br><li>.*?<\/li>)*)/g, '<ul class="mb-3 pl-6 list-disc space-y-1">$1</ul>');
    html = html.replace(/<br><li>/g, '<li>');

    // Wrap table rows in table
    if (html.includes('<tr>')) {
      html = html.replace(/(<tr>.*?<\/tr>)+/g, '<table class="w-full border-collapse border border-gray-300 dark:border-gray-600 mb-4 rounded-lg overflow-hidden">$&</table>');
    }

    return html;
  };

  const ToolbarButton: React.FC<{
    onClick: () => void;
    icon: React.ReactNode;
    title: string;
    active?: boolean;
    disabled?: boolean;
  }> = ({ onClick, icon, title, active = false, disabled = false }) => (
    <button
      type="button"
      onClick={onClick}
      title={title}
      disabled={disabled}
      className={`p-2 rounded-lg transition-all duration-200 ${
        disabled 
          ? 'opacity-50 cursor-not-allowed' 
          : 
        active 
          ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 shadow-sm' 
          : 'hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-400 hover:shadow-sm'
      }`}
    >
      {icon}
    </button>
  );

  const EditorContent = () => (
    <div className="flex flex-col h-full">
      {/* Enhanced Toolbar - Always visible, but disabled in preview mode */}
      <div className="bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700 border-b border-gray-200 dark:border-gray-600 p-3 flex items-center gap-2 flex-wrap shadow-sm">
        {/* Text Formatting */}
        <div className={`flex items-center gap-1 bg-white dark:bg-gray-800 rounded-lg p-1 shadow-sm transition-opacity ${isPreview ? 'opacity-50 pointer-events-none' : 'opacity-100'}`}>
          <ToolbarButton
            onClick={() => formatText('**', '**')}
            icon={<Bold className="w-4 h-4" />}
            title="عريض (Bold)"
            disabled={isPreview}
          />
          <ToolbarButton
            onClick={() => formatText('*', '*')}
            icon={<Italic className="w-4 h-4" />}
            title="مائل (Italic)"
            disabled={isPreview}
          />
          <ToolbarButton
            onClick={() => formatText('~~', '~~')}
            icon={<Strikethrough className="w-4 h-4" />}
            title="يتوسطه خط (Strikethrough)"
            disabled={isPreview}
          />
        </div>

        <div className={`w-px h-6 bg-gray-300 dark:bg-gray-600 ${isPreview ? 'opacity-50' : 'opacity-100'}`}></div>

        {/* Headers */}
        <div className={`flex items-center gap-1 bg-white dark:bg-gray-800 rounded-lg p-1 shadow-sm transition-opacity ${isPreview ? 'opacity-50 pointer-events-none' : 'opacity-100'}`}>
          <ToolbarButton
            onClick={() => formatText('\n# ', '')}
            icon={<Heading1 className="w-4 h-4" />}
            title="عنوان رئيسي (H1)"
            disabled={isPreview}
          />
          <ToolbarButton
            onClick={() => formatText('\n## ', '')}
            icon={<Heading2 className="w-4 h-4" />}
            title="عنوان فرعي (H2)"
            disabled={isPreview}
          />
          <ToolbarButton
            onClick={() => formatText('\n### ', '')}
            icon={<Heading3 className="w-4 h-4" />}
            title="عنوان صغير (H3)"
            disabled={isPreview}
          />
        </div>

        <div className={`w-px h-6 bg-gray-300 dark:bg-gray-600 ${isPreview ? 'opacity-50' : 'opacity-100'}`}></div>

        {/* Lists and Structure */}
        <div className={`flex items-center gap-1 bg-white dark:bg-gray-800 rounded-lg p-1 shadow-sm transition-opacity ${isPreview ? 'opacity-50 pointer-events-none' : 'opacity-100'}`}>
          <ToolbarButton
            onClick={() => formatText('\n- ', '')}
            icon={<List className="w-4 h-4" />}
            title="قائمة نقطية (Bullet List)"
            disabled={isPreview}
          />
          <ToolbarButton
            onClick={() => formatText('\n1. ', '')}
            icon={<ListOrdered className="w-4 h-4" />}
            title="قائمة مرقمة (Numbered List)"
            disabled={isPreview}
          />
          <ToolbarButton
            onClick={() => formatText('\n> ', '')}
            icon={<Quote className="w-4 h-4" />}
            title="اقتباس (Quote)"
            disabled={isPreview}
          />
        </div>

        <div className={`w-px h-6 bg-gray-300 dark:bg-gray-600 ${isPreview ? 'opacity-50' : 'opacity-100'}`}></div>

        {/* Code and Media */}
        <div className={`flex items-center gap-1 bg-white dark:bg-gray-800 rounded-lg p-1 shadow-sm transition-opacity ${isPreview ? 'opacity-50 pointer-events-none' : 'opacity-100'}`}>
          <ToolbarButton
            onClick={() => formatText('`', '`')}
            icon={<Code className="w-4 h-4" />}
            title="كود مضمن (Inline Code)"
            disabled={isPreview}
          />
          <ToolbarButton
            onClick={() => formatText('\n```\n', '\n```\n')}
            icon={<Code className="w-5 h-5" />}
            title="بلوك كود (Code Block)"
            disabled={isPreview}
          />
          <ToolbarButton
            onClick={() => formatText('[', '](url)')}
            icon={<Link className="w-4 h-4" />}
            title="رابط (Link)"
            disabled={isPreview}
          />
          <ToolbarButton
            onClick={() => formatText('![alt text](', ')')}
            icon={<Image className="w-4 h-4" />}
            title="صورة (Image)"
            disabled={isPreview}
          />
        </div>

        <div className={`w-px h-6 bg-gray-300 dark:bg-gray-600 ${isPreview ? 'opacity-50' : 'opacity-100'}`}></div>

        {/* Special Elements */}
        <div className={`flex items-center gap-1 bg-white dark:bg-gray-800 rounded-lg p-1 shadow-sm transition-opacity ${isPreview ? 'opacity-50 pointer-events-none' : 'opacity-100'}`}>
          <ToolbarButton
            onClick={() => insertText('\n---\n')}
            icon={<Separator className="w-4 h-4" />}
            title="خط فاصل (Horizontal Rule)"
            disabled={isPreview}
          />
          <ToolbarButton
            onClick={() => insertText('\n| Header 1 | Header 2 |\n|----------|----------|\n| Cell 1   | Cell 2   |\n')}
            icon={<Table className="w-4 h-4" />}
            title="جدول (Table)"
            disabled={isPreview}
          />
        </div>

        <div className={`w-px h-6 bg-gray-300 dark:bg-gray-600 ${isPreview ? 'opacity-50' : 'opacity-100'}`}></div>

        {/* Text Direction */}
        <div className={`flex items-center gap-1 bg-white dark:bg-gray-800 rounded-lg p-1 shadow-sm transition-opacity ${isPreview ? 'opacity-50 pointer-events-none' : 'opacity-100'}`}>
          <ToolbarButton
            onClick={() => setTextDirection(textDirection === 'ltr' ? 'rtl' : 'ltr')}
            icon={textDirection === 'ltr' ? <AlignLeft className="w-4 h-4" /> : <AlignRight className="w-4 h-4" />}
            title={textDirection === 'ltr' ? 'تبديل إلى العربية' : 'تبديل إلى الإنجليزية'}
            active={textDirection === 'rtl'}
            disabled={isPreview}
          />
        </div>

        <div className="flex-1"></div>

        {/* View Controls */}
        <div className="flex items-center gap-1 bg-white dark:bg-gray-800 rounded-lg p-1 shadow-sm">
          <ToolbarButton
            onClick={togglePreview}
            icon={isPreview ? <Edit3 className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            title={isPreview ? 'وضع التحرير' : 'وضع المعاينة'}
            active={isPreview}
          />
          <ToolbarButton
            onClick={() => setIsFullscreen(!isFullscreen)}
            icon={isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            title="ملء الشاشة"
          />
          {onSave && (
            <ToolbarButton
              onClick={onSave}
              icon={<Save className="w-4 h-4" />}
              title="حفظ (Ctrl+Enter)"
            />
          )}
        </div>
      </div>

      {/* Editor/Preview Area */}
      <div className="flex-1">
        {isPreview ? (
          <div 
            className={`h-full p-6 overflow-auto bg-white dark:bg-gray-900 prose prose-gray dark:prose-invert max-w-none ${
              textDirection === 'rtl' ? 'text-right' : 'text-left'
            }`}
            style={{ direction: textDirection }}
            dangerouslySetInnerHTML={{ __html: getPreviewHTML() }}
          />
        ) : (
          <textarea
            ref={textareaRef}
            value={value}
            onChange={handleChange}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            className={`w-full h-full p-6 bg-white dark:bg-gray-900 border-none resize-none focus:outline-none text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 text-base leading-relaxed font-mono ${
              textDirection === 'rtl' ? 'text-right' : 'text-left'
            }`}
            style={{ 
              minHeight: '400px',
              direction: textDirection,
              fontFamily: textDirection === 'rtl' ? 'Tajawal, Cairo, sans-serif' : 'Fira Code, SF Mono, Monaco, Consolas, monospace'
            }}
            spellCheck={false}
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="off"
            data-gramm="false"
            data-gramm_editor="false"
            data-enable-grammarly="false"
            autoFocus={!isPreview}
          />
        )}
      </div>
    </div>
  );

  if (isFullscreen) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-95 z-50 flex flex-col">
        <div className="bg-white dark:bg-gray-900 m-4 rounded-lg flex-1 flex flex-col overflow-hidden shadow-2xl">
          <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-gray-800 dark:to-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              محرر النصوص المتقدم - وضع ملء الشاشة
            </h2>
            <button
              onClick={() => setIsFullscreen(false)}
              className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors shadow-sm"
            >
              إغلاق ملء الشاشة
            </button>
          </div>
          <div className="flex-1 overflow-hidden">
            <EditorContent />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`h-full flex flex-col ${className} shadow-lg rounded-lg overflow-hidden`}>
      <EditorContent />
    </div>
  );
};