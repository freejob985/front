import React, { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import { 
  Bold, 
  Italic, 
  Underline, 
  List, 
  ListOrdered, 
  Quote, 
  Code, 
  Maximize2, 
  Minimize2,
  Type,
  AlignLeft,
  AlignRight,
  Save,
  Eye,
  Edit3
} from 'lucide-react';

interface AdvancedTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  onSave?: () => void;
  placeholder?: string;
  className?: string;
}

export const AdvancedTextEditor: React.FC<AdvancedTextEditorProps> = ({
  value,
  onChange,
  onSave,
  placeholder = "Start writing your documentation here...",
  className = ""
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isPreview, setIsPreview] = useState(false);
  const [textDirection, setTextDirection] = useState<'ltr' | 'rtl'>('ltr');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Memoize the textarea change handler to prevent recreation
  const handleTextareaChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onChange(e.target.value);
  }, [onChange]);

  // Auto-resize textarea - use useCallback to prevent recreation
  const adjustTextareaHeight = useCallback(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = Math.max(300, textarea.scrollHeight) + 'px';
    }
  }, []);

  // Only adjust height when value changes, not on every render
  useEffect(() => {
    adjustTextareaHeight();
  }, [value, adjustTextareaHeight]);

  const insertText = useCallback((before: string, after: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = value.substring(start, end);
    
    const newText = value.substring(0, start) + before + selectedText + after + value.substring(end);
    onChange(newText);

    // Restore cursor position after state update
    requestAnimationFrame(() => {
      if (textarea) {
        textarea.focus();
        const newCursorPos = start + before.length + selectedText.length;
        textarea.setSelectionRange(newCursorPos, newCursorPos);
      }
    });
  }, [value, onChange]);

  const formatText = useCallback((type: string) => {
    switch (type) {
      case 'bold':
        insertText('**', '**');
        break;
      case 'italic':
        insertText('*', '*');
        break;
      case 'underline':
        insertText('<u>', '</u>');
        break;
      case 'code':
        insertText('`', '`');
        break;
      case 'codeblock':
        insertText('\n```\n', '\n```\n');
        break;
      case 'quote':
        insertText('\n> ', '');
        break;
      case 'ul':
        insertText('\n- ', '');
        break;
      case 'ol':
        insertText('\n1. ', '');
        break;
      case 'h1':
        insertText('\n# ', '');
        break;
      case 'h2':
        insertText('\n## ', '');
        break;
      case 'h3':
        insertText('\n### ', '');
        break;
    }
  }, [insertText]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      insertText('  ');
    } else if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      onSave?.();
    }
  }, [insertText, onSave]);

  // Memoize the preview HTML to prevent unnecessary recalculations
  const previewHTML = useMemo(() => {
    let html = value
      // Headers
      .replace(/^### (.*$)/gm, '<h3 class="text-lg font-semibold mb-2 text-gray-900 dark:text-white">$1</h3>')
      .replace(/^## (.*$)/gm, '<h2 class="text-xl font-semibold mb-3 text-gray-900 dark:text-white">$1</h2>')
      .replace(/^# (.*$)/gm, '<h1 class="text-2xl font-bold mb-4 text-gray-900 dark:text-white">$1</h1>')
      // Bold and italic
      .replace(/\*\*(.*?)\*\*/g, '<strong class="font-bold">$1</strong>')
      .replace(/\*(.*?)\*/g, '<em class="italic">$1</em>')
      // Underline
      .replace(/<u>(.*?)<\/u>/g, '<u class="underline">$1</u>')
      // Code blocks
      .replace(/```([\s\S]*?)```/g, '<pre class="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg mb-4 overflow-x-auto"><code class="text-sm font-mono">$1</code></pre>')
      // Inline code
      .replace(/`(.*?)`/g, '<code class="bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded text-sm font-mono text-gray-800 dark:text-gray-200">$1</code>')
      // Quotes
      .replace(/^> (.*$)/gm, '<blockquote class="border-l-4 border-blue-500 pl-4 italic text-gray-600 dark:text-gray-400 mb-4">$1</blockquote>')
      // Lists
      .replace(/^- (.*$)/gm, '<li class="mb-1 text-gray-700 dark:text-gray-300">$1</li>')
      .replace(/^\d+\. (.*$)/gm, '<li class="mb-1 text-gray-700 dark:text-gray-300">$1</li>')
      // Line breaks
      .replace(/\n\n/g, '</p><p class="mb-3 text-gray-700 dark:text-gray-300">')
      .replace(/\n/g, '<br>');

    // Wrap in paragraph tags
    if (html && !html.startsWith('<h') && !html.startsWith('<ul') && !html.startsWith('<ol') && !html.startsWith('<blockquote')) {
      html = '<p class="mb-3 text-gray-700 dark:text-gray-300">' + html + '</p>';
    }

    // Wrap consecutive <li> elements in <ul> or <ol>
    html = html.replace(/(<li>.*?<\/li>(?:<br><li>.*?<\/li>)*)/g, '<ul class="mb-3 pl-6 list-disc">$1</ul>');
    html = html.replace(/<br><li>/g, '<li>');

    return { __html: html };
  }, [value]);

  // Memoize toolbar button component to prevent recreation
  const ToolbarButton = useMemo(() => React.memo<{
    onClick: () => void;
    icon: React.ReactNode;
    title: string;
    active?: boolean;
  }>(({ onClick, icon, title, active = false }) => (
    <button
      type="button"
      onClick={onClick}
      title={title}
      className={`p-2 rounded-lg transition-colors ${
        active 
          ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300' 
          : 'hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-400'
      }`}
    >
      {icon}
    </button>
  )), []);

  // Memoize toolbar handlers to prevent recreation
  const toolbarHandlers = useMemo(() => ({
    bold: () => formatText('bold'),
    italic: () => formatText('italic'),
    underline: () => formatText('underline'),
    h1: () => formatText('h1'),
    h2: () => formatText('h2'),
    h3: () => formatText('h3'),
    ul: () => formatText('ul'),
    ol: () => formatText('ol'),
    quote: () => formatText('quote'),
    code: () => formatText('code'),
    codeblock: () => formatText('codeblock'),
    toggleDirection: () => setTextDirection(prev => prev === 'ltr' ? 'rtl' : 'ltr'),
    togglePreview: () => setIsPreview(prev => !prev),
    toggleFullscreen: () => setIsFullscreen(prev => !prev),
    save: onSave || (() => {})
  }), [formatText, onSave]);

  const EditorContent = useMemo(() => () => (
    <div className="advanced-editor flex-1 flex flex-col h-full">
      {/* Toolbar */}
      <div className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-3 flex items-center gap-2 flex-wrap">
        <div className="flex items-center gap-1">
          <ToolbarButton
            onClick={toolbarHandlers.bold}
            icon={<Bold className="w-4 h-4" />}
            title="عريض (Ctrl+B)"
          />
          <ToolbarButton
            onClick={toolbarHandlers.italic}
            icon={<Italic className="w-4 h-4" />}
            title="مائل (Ctrl+I)"
          />
          <ToolbarButton
            onClick={toolbarHandlers.underline}
            icon={<Underline className="w-4 h-4" />}
            title="تحته خط"
          />
        </div>

        <div className="w-px h-6 bg-gray-300 dark:bg-gray-600"></div>

        <div className="flex items-center gap-1">
          <ToolbarButton
            onClick={toolbarHandlers.h1}
            icon={<Type className="w-4 h-4" />}
            title="عنوان رئيسي"
          />
          <ToolbarButton
            onClick={toolbarHandlers.h2}
            icon={<Type className="w-3 h-3" />}
            title="عنوان فرعي"
          />
          <ToolbarButton
            onClick={toolbarHandlers.h3}
            icon={<Type className="w-2 h-2" />}
            title="عنوان صغير"
          />
        </div>

        <div className="w-px h-6 bg-gray-300 dark:bg-gray-600"></div>

        <div className="flex items-center gap-1">
          <ToolbarButton
            onClick={toolbarHandlers.ul}
            icon={<List className="w-4 h-4" />}
            title="قائمة نقطية"
          />
          <ToolbarButton
            onClick={toolbarHandlers.ol}
            icon={<ListOrdered className="w-4 h-4" />}
            title="قائمة مرقمة"
          />
          <ToolbarButton
            onClick={toolbarHandlers.quote}
            icon={<Quote className="w-4 h-4" />}
            title="اقتباس"
          />
        </div>

        <div className="w-px h-6 bg-gray-300 dark:bg-gray-600"></div>

        <div className="flex items-center gap-1">
          <ToolbarButton
            onClick={toolbarHandlers.code}
            icon={<Code className="w-4 h-4" />}
            title="كود مضمن"
          />
          <ToolbarButton
            onClick={toolbarHandlers.codeblock}
            icon={<Code className="w-4 h-4" />}
            title="بلوك كود"
          />
        </div>

        <div className="w-px h-6 bg-gray-300 dark:bg-gray-600"></div>

        <div className="flex items-center gap-1">
          <ToolbarButton
            onClick={toolbarHandlers.toggleDirection}
            icon={textDirection === 'ltr' ? <AlignLeft className="w-4 h-4" /> : <AlignRight className="w-4 h-4" />}
            title={textDirection === 'ltr' ? 'تبديل إلى العربية' : 'تبديل إلى الإنجليزية'}
            active={textDirection === 'rtl'}
          />
        </div>

        <div className="flex-1"></div>

        <div className="flex items-center gap-1">
          <ToolbarButton
            onClick={toolbarHandlers.togglePreview}
            icon={isPreview ? <Edit3 className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            title={isPreview ? 'وضع التحرير' : 'وضع المعاينة'}
            active={isPreview}
          />
          <ToolbarButton
            onClick={toolbarHandlers.toggleFullscreen}
            icon={isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            title={isFullscreen ? 'إغلاق ملء الشاشة' : 'ملء الشاشة'}
          />
          {onSave && (
            <ToolbarButton
              onClick={toolbarHandlers.save}
              icon={<Save className="w-4 h-4" />}
              title="حفظ (Ctrl+Enter)"
            />
          )}
        </div>
      </div>

      {/* Editor/Preview Area */}
      <div className="flex-1 flex">
        {isPreview ? (
          <div 
            className={`flex-1 p-6 overflow-auto bg-white dark:bg-gray-900 ${textDirection === 'rtl' ? 'text-right' : 'text-left'}`}
            style={{ direction: textDirection }}
            dangerouslySetInnerHTML={previewHTML}
          />
        ) : (
          <textarea
            ref={textareaRef}
            value={value}
            onChange={handleTextareaChange}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            className={`flex-1 p-6 bg-white dark:bg-gray-900 border-none resize-none focus:outline-none text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 text-base leading-relaxed ${className}`}
            style={{ 
              minHeight: '400px',
              direction: textDirection,
              fontFamily: textDirection === 'rtl' ? 'Tajawal, Cairo, sans-serif' : 'inherit'
            }}
            dir={textDirection}
            autoFocus={false}
          />
        )}
      </div>
    </div>
  ), [value, handleTextareaChange, handleKeyDown, placeholder, className, textDirection, isPreview, previewHTML, ToolbarButton, toolbarHandlers, isFullscreen]);

  if (isFullscreen) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-95 z-50 flex flex-col">
        <div className="bg-white dark:bg-gray-900 m-4 rounded-lg flex-1 flex flex-col overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              محرر النصوص المتقدم - وضع ملء الشاشة
            </h2>
            <button
              onClick={() => setIsFullscreen(false)}
              className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
            >
              إغلاق ملء الشاشة
            </button>
          </div>
          <div className="flex-1 overflow-hidden">
            <EditorContent />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`h-full flex flex-col ${className}`}>
      <EditorContent />
    </div>
  );
};