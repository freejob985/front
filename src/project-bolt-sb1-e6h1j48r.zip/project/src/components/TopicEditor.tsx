import React, { useState, useEffect } from 'react';
import { Save, Clock, Tag } from 'lucide-react';
import { Topic } from '../types';
import { SimpleTextEditor } from './SimpleTextEditor';

interface TopicEditorProps {
  topic: Topic | null;
  onSave: (id: string, updates: Partial<Topic>) => void;
}

export const TopicEditor: React.FC<TopicEditorProps> = ({ topic, onSave }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Update state when topic changes
  useEffect(() => {
    if (topic) {
      setTitle(topic.title);
      setContent(topic.content);
      setTags(topic.tags);
      setHasUnsavedChanges(false);
    }
  }, [topic]);

  // Check for unsaved changes
  useEffect(() => {
    if (topic) {
      const hasChanges = 
        title !== topic.title ||
        content !== topic.content ||
        JSON.stringify(tags) !== JSON.stringify(topic.tags);
      setHasUnsavedChanges(hasChanges);
      
      // Update the data attribute for unsaved changes detection
      const editorElement = document.querySelector('[data-has-unsaved-changes]');
      if (editorElement) {
        editorElement.setAttribute('data-has-unsaved-changes', hasChanges.toString());
      }
    }
  }, [title, content, tags, topic]);

  const handleSave = () => {
    if (topic) {
      onSave(topic.id, {
        title,
        content,
        tags
      });
      setHasUnsavedChanges(false);
    }
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      handleSave();
    }
  };

  if (!topic) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-center text-gray-500 dark:text-gray-400">
          <div className="w-16 h-16 bg-gray-200 dark:bg-gray-700 rounded-lg flex items-center justify-center mx-auto mb-4">
            📝
          </div>
          <h2 className="text-lg font-medium mb-2">Select a topic to edit</h2>
          <p>Choose a topic from the sidebar to start editing its content</p>
        </div>
      </div>
    );
  }

  if (topic.isFolder) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-center text-gray-500 dark:text-gray-400">
          <div className="w-16 h-16 bg-yellow-200 dark:bg-yellow-700 rounded-lg flex items-center justify-center mx-auto mb-4">
            📁
          </div>
          <h2 className="text-lg font-medium mb-2">This is a folder</h2>
          <p>Folders are used to organize topics. Select a topic to edit its content.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-white dark:bg-gray-900">
      {/* Header */}
      <div className="border-b border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center justify-between mb-4">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onKeyDown={handleKeyDown}
            className="text-2xl font-bold bg-transparent border-none outline-none text-gray-900 dark:text-white placeholder-gray-500 flex-1 mr-4"
            placeholder="Topic title..."
          />
          <div className="flex items-center gap-3">
            {hasUnsavedChanges && (
              <span className="inline-flex items-center gap-1 text-sm text-amber-600 dark:text-amber-400">
                <Clock className="w-4 h-4" />
                Unsaved changes
              </span>
            )}
            <button
              onClick={handleSave}
              disabled={!hasUnsavedChanges}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                hasUnsavedChanges
                  ? 'bg-blue-600 text-white hover:bg-blue-700'
                  : 'bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed'
              }`}
            >
              <Save className="w-4 h-4" />
              Save
            </button>
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap items-center gap-2 mb-4">
          <Tag className="w-4 h-4 text-gray-500 dark:text-gray-400" />
          {tags.map((tag) => (
            <span
              key={tag}
              className="inline-flex items-center gap-1 px-2 py-1 bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 rounded-md text-sm"
            >
              {tag}
              <button
                onClick={() => handleRemoveTag(tag)}
                className="ml-1 hover:bg-blue-200 dark:hover:bg-blue-800 rounded-full p-0.5"
              >
                ×
              </button>
            </span>
          ))}
          <input
            type="text"
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                handleAddTag();
              }
            }}
            placeholder="Add tag..."
            className="px-2 py-1 text-sm bg-transparent border border-dashed border-gray-300 dark:border-gray-600 rounded text-gray-700 dark:text-gray-300 placeholder-gray-500 dark:placeholder-gray-400 min-w-[100px]"
          />
        </div>

        <div className="text-sm text-gray-500 dark:text-gray-400">
          <span>Last updated: {topic.updatedAt.toLocaleDateString()}</span>
          <span className="ml-4">Press Ctrl/Cmd + Enter to save quickly</span>
        </div>
      </div>

      {/* Content Editor */}
      <div className="flex-1 p-6">
        <div 
          className="flex flex-col" 
          style={{ height: 'calc(100vh - 300px)' }}
          data-has-unsaved-changes={hasUnsavedChanges}
        >
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
            محتوى الموضوع
          </h3>
          
          <SimpleTextEditor
            value={content}
            onChange={setContent}
            onSave={handleSave}
            placeholder="ابدأ في كتابة التوثيق هنا...

يمكنك تضمين:
- أمثلة الكود
- الملاحظات والشروحات
- أفضل الممارسات
- الأنماط الشائعة
- نصائح استكشاف الأخطاء

نصيحة: استخدم Ctrl/Cmd + Enter للحفظ السريع!"
            className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden flex-1"
          />
        </div>
      </div>
    </div>
  );
};