import React from 'react';
import { Moon, Sun, Menu, Download, Upload, Settings, Database, FolderSync as Sync } from 'lucide-react';
import Swal from 'sweetalert2';
import { toast } from 'react-toastify';
import { storage } from '../utils/storage';
import { exportUtils } from '../utils/export';
import { DatabaseService } from '../utils/database';

interface HeaderProps {
  darkMode: boolean;
  sidebarCollapsed: boolean;
  onToggleTheme: () => void;
  onToggleSidebar: () => void;
  onDataImported: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  darkMode,
  sidebarCollapsed,
  onToggleTheme,
  onToggleSidebar,
  onDataImported
}) => {
  const handleExport = () => {
    try {
      const data = storage.exportData();
      const timestamp = new Date().toISOString().split('T')[0];
      exportUtils.downloadJSON(data, `documentation-${timestamp}.json`);
      toast.success('Documentation exported successfully!');
    } catch (error) {
      toast.error('Failed to export documentation');
    }
  };

  const handleImport = async () => {
    const result = await Swal.fire({
      title: 'Import Documentation',
      text: 'This will replace all current data. Are you sure?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3B82F6',
      cancelButtonColor: '#EF4444',
      confirmButtonText: 'Yes, import',
      cancelButtonText: 'Cancel'
    });

    if (result.isConfirmed) {
      try {
        const data = await exportUtils.importFromFile();
        storage.importData(data);
        onDataImported();
        toast.success('Documentation imported successfully!');
      } catch (error) {
        toast.error('Failed to import documentation');
      }
    }
  };

  const handleSyncToDatabase = async () => {
    const result = await Swal.fire({
      title: 'مزامنة مع قاعدة البيانات',
      text: 'سيتم حفظ جميع البيانات المحلية في قاعدة البيانات',
      icon: 'info',
      showCancelButton: true,
      confirmButtonColor: '#3B82F6',
      cancelButtonColor: '#6B7280',
      confirmButtonText: 'نعم، مزامنة',
      cancelButtonText: 'إلغاء'
    });

    if (result.isConfirmed) {
      const languages = storage.getLanguages();
      const topics = storage.getTopics();
      await DatabaseService.syncToDatabase(languages, topics);
    }
  };

  const handleLoadFromDatabase = async () => {
    const result = await Swal.fire({
      title: 'تحميل من قاعدة البيانات',
      text: 'سيتم استبدال جميع البيانات المحلية بالبيانات من قاعدة البيانات',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3B82F6',
      cancelButtonColor: '#EF4444',
      confirmButtonText: 'نعم، تحميل',
      cancelButtonText: 'إلغاء'
    });

    if (result.isConfirmed) {
      const { languages, topics } = await DatabaseService.loadFromDatabase();
      storage.saveLanguages(languages);
      storage.saveTopics(topics);
      onDataImported();
    }
  };
  const handleClearAll = async () => {
    const result = await Swal.fire({
      title: 'Clear All Data',
      text: 'This will permanently delete all languages and topics. This action cannot be undone!',
      icon: 'error',
      showCancelButton: true,
      confirmButtonColor: '#EF4444',
      cancelButtonColor: '#6B7280',
      confirmButtonText: 'Yes, delete all',
      cancelButtonText: 'Cancel',
      input: 'text',
      inputPlaceholder: 'Type "DELETE" to confirm',
      preConfirm: (value) => {
        if (value !== 'DELETE') {
          Swal.showValidationMessage('Please type "DELETE" to confirm');
          return false;
        }
        return true;
      }
    });

    if (result.isConfirmed) {
      storage.clearAll();
      onDataImported();
      toast.success('All data cleared successfully!');
    }
  };

  return (
    <header className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex items-center justify-between">
      <div className="flex items-center gap-4">
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          title={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          <Menu className="w-5 h-5 text-gray-600 dark:text-gray-400" />
        </button>
        
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
            <span className="text-white text-lg font-bold">📚</span>
          </div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">
            Programming Docs
          </h1>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={handleSyncToDatabase}
          className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          title="مزامنة مع قاعدة البيانات"
        >
          <Sync className="w-5 h-5 text-green-600 dark:text-green-400" />
        </button>

        <button
          onClick={handleLoadFromDatabase}
          className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          title="تحميل من قاعدة البيانات"
        >
          <Database className="w-5 h-5 text-blue-600 dark:text-blue-400" />
        </button>
        <button
          onClick={handleExport}
          className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          title="Export documentation"
        >
          <Download className="w-5 h-5 text-gray-600 dark:text-gray-400" />
        </button>

        <button
          onClick={handleImport}
          className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          title="Import documentation"
        >
          <Upload className="w-5 h-5 text-gray-600 dark:text-gray-400" />
        </button>

        <button
          onClick={handleClearAll}
          className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          title="Clear all data"
        >
          <Settings className="w-5 h-5 text-gray-600 dark:text-gray-400" />
        </button>

        <button
          onClick={onToggleTheme}
          className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          title={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
        >
          {darkMode ? (
            <Sun className="w-5 h-5 text-yellow-500" />
          ) : (
            <Moon className="w-5 h-5 text-gray-600" />
          )}
        </button>
      </div>
    </header>
  );
};