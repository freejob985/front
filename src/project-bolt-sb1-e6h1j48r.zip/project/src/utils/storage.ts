import { Language, Topic, ExportData } from '../types';

const STORAGE_KEYS = {
  LANGUAGES: 'doc_languages',
  TOPICS: 'doc_topics',
  SETTINGS: 'doc_settings',
  THEME: 'doc_theme'
};

export const storage = {
  // Languages
  saveLanguages: (languages: Language[]) => {
    localStorage.setItem(STORAGE_KEYS.LANGUAGES, JSON.stringify(languages));
  },

  getLanguages: (): Language[] => {
    const stored = localStorage.getItem(STORAGE_KEYS.LANGUAGES);
    if (!stored) return [];
    try {
      const parsed = JSON.parse(stored);
      return parsed.map((lang: any) => ({
        ...lang,
        createdAt: new Date(lang.createdAt),
        updatedAt: new Date(lang.updatedAt)
      }));
    } catch {
      return [];
    }
  },

  // Topics
  saveTopics: (topics: Topic[]) => {
    localStorage.setItem(STORAGE_KEYS.TOPICS, JSON.stringify(topics));
  },

  getTopics: (): Topic[] => {
    const stored = localStorage.getItem(STORAGE_KEYS.TOPICS);
    if (!stored) return [];
    try {
      const parsed = JSON.parse(stored);
      return parsed.map((topic: any) => ({
        ...topic,
        createdAt: new Date(topic.createdAt),
        updatedAt: new Date(topic.updatedAt)
      }));
    } catch {
      return [];
    }
  },

  // Settings
  saveSettings: (settings: any) => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  },

  getSettings: () => {
    const stored = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!stored) return {};
    try {
      return JSON.parse(stored);
    } catch {
      return {};
    }
  },

  // Theme
  saveTheme: (isDark: boolean) => {
    localStorage.setItem(STORAGE_KEYS.THEME, JSON.stringify(isDark));
  },

  getTheme: (): boolean => {
    const stored = localStorage.getItem(STORAGE_KEYS.THEME);
    if (!stored) return false;
    try {
      return JSON.parse(stored);
    } catch {
      return false;
    }
  },

  // Export/Import
  exportData: (): ExportData => {
    return {
      languages: storage.getLanguages(),
      topics: storage.getTopics(),
      exportDate: new Date(),
      version: '1.0.0'
    };
  },

  importData: (data: ExportData) => {
    if (data.languages) {
      storage.saveLanguages(data.languages);
    }
    if (data.topics) {
      storage.saveTopics(data.topics);
    }
  },

  // Clear all data
  clearAll: () => {
    Object.values(STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
  }
};