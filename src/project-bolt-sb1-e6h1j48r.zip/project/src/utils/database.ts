import { supabase } from '../lib/supabase';
import { Language, Topic } from '../types';
import { toast } from 'react-toastify';

export class DatabaseService {
  // Languages
  static async getLanguages(): Promise<Language[]> {
    try {
      const { data, error } = await supabase
        .from('languages')
        .select('*')
        .order('created_at', { ascending: true });

      if (error) throw error;

      return (data || []).map(lang => ({
        id: lang.id,
        name: lang.name,
        icon: lang.icon,
        color: lang.color,
        createdAt: new Date(lang.created_at),
        updatedAt: new Date(lang.updated_at)
      }));
    } catch (error) {
      console.error('Error fetching languages:', error);
      return [];
    }
  }

  static async saveLanguage(language: Language): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('languages')
        .upsert({
          id: language.id,
          name: language.name,
          icon: language.icon,
          color: language.color,
          created_at: language.createdAt.toISOString(),
          updated_at: language.updatedAt.toISOString()
        });

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error saving language:', error);
      toast.error('فشل في حفظ اللغة في قاعدة البيانات');
      return false;
    }
  }

  static async deleteLanguage(id: string): Promise<boolean> {
    try {
      // Delete all topics for this language first
      await supabase
        .from('topics')
        .delete()
        .eq('language_id', id);

      // Then delete the language
      const { error } = await supabase
        .from('languages')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error deleting language:', error);
      toast.error('فشل في حذف اللغة من قاعدة البيانات');
      return false;
    }
  }

  // Topics
  static async getTopics(): Promise<Topic[]> {
    try {
      const { data, error } = await supabase
        .from('topics')
        .select('*')
        .order('created_at', { ascending: true });

      if (error) throw error;

      return (data || []).map(topic => ({
        id: topic.id,
        languageId: topic.language_id,
        title: topic.title,
        content: topic.content,
        tags: topic.tags || [],
        parentId: topic.parent_id,
        isFolder: topic.is_folder || false,
        createdAt: new Date(topic.created_at),
        updatedAt: new Date(topic.updated_at)
      }));
    } catch (error) {
      console.error('Error fetching topics:', error);
      return [];
    }
  }

  static async saveTopic(topic: Topic): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('topics')
        .upsert({
          id: topic.id,
          language_id: topic.languageId,
          title: topic.title,
          content: topic.content,
          tags: topic.tags,
          parent_id: topic.parentId,
          is_folder: topic.isFolder || false,
          created_at: topic.createdAt.toISOString(),
          updated_at: topic.updatedAt.toISOString()
        });

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error saving topic:', error);
      toast.error('فشل في حفظ الموضوع في قاعدة البيانات');
      return false;
    }
  }

  static async deleteTopic(id: string): Promise<boolean> {
    try {
      // Get all subtopics recursively
      const getAllSubtopics = async (topicId: string): Promise<string[]> => {
        const { data } = await supabase
          .from('topics')
          .select('id')
          .eq('parent_id', topicId);
        
        const ids = [topicId];
        if (data) {
          for (const subtopic of data) {
            ids.push(...await getAllSubtopics(subtopic.id));
          }
        }
        return ids;
      };

      const idsToDelete = await getAllSubtopics(id);
      
      const { error } = await supabase
        .from('topics')
        .delete()
        .in('id', idsToDelete);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error deleting topic:', error);
      toast.error('فشل في حذف الموضوع من قاعدة البيانات');
      return false;
    }
  }

  // Sync operations
  static async syncToDatabase(languages: Language[], topics: Topic[]): Promise<boolean> {
    try {
      // Save all languages
      for (const language of languages) {
        await this.saveLanguage(language);
      }

      // Save all topics
      for (const topic of topics) {
        await this.saveTopic(topic);
      }

      toast.success('تم مزامنة البيانات مع قاعدة البيانات بنجاح');
      return true;
    } catch (error) {
      console.error('Error syncing to database:', error);
      toast.error('فشل في مزامنة البيانات مع قاعدة البيانات');
      return false;
    }
  }

  static async loadFromDatabase(): Promise<{ languages: Language[], topics: Topic[] }> {
    try {
      // Test connection first
      const { data: testData, error: testError } = await supabase
        .from('languages')
        .select('count')
        .limit(1);
      
      if (testError) {
        console.error('Database connection test failed:', testError);
        throw testError;
      }

      const [languages, topics] = await Promise.all([
        this.getLanguages(),
        this.getTopics()
      ]);

      console.log('Loaded from database:', { languages: languages.length, topics: topics.length });
      return { languages, topics };
    } catch (error) {
      console.error('Error loading from database:', error);
      return { languages: [], topics: [] };
    }
  }
}