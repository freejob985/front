export interface Language {
  id: string;
  name: string;
  icon: string;
  color: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Topic {
  id: string;
  languageId: string;
  title: string;
  content: string;
  tags: string[];
  parentId?: string;
  isFolder?: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface AppState {
  languages: Language[];
  topics: Topic[];
  selectedLanguageId: string | null;
  selectedTopicId: string | null;
  searchTerm: string;
  darkMode: boolean;
  sidebarCollapsed: boolean;
}

export interface ExportData {
  languages: Language[];
  topics: Topic[];
  exportDate: Date;
  version: string;
}